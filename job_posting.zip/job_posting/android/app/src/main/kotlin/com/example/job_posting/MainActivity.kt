package com.example.job_posting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
